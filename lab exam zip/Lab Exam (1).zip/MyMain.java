import com.mypackages.*;

public class MyMain
{
	public static void main(String[] args) { 
	login obj = new login();  
 
	}
}