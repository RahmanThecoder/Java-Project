import mypackage.*;
	
public class MyMain
{
	public static void main(String[] args) { 
	 A obj = new A();  
 
	}
}	